# utils.py
import os
import hashlib
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

import scipy.sparse as sp
from ppr import topk_ppr_matrix
from scipy.sparse import issparse, coo_matrix
from torch_geometric.utils import degree, to_dense_adj
from scipy.sparse.linalg import inv as sparse_inv
from scipy.sparse import identity, csr_matrix

class CrossEntropy(nn.Module):
    def __init__(self):
        super(CrossEntropy, self).__init__()

    def forward(self, input, target, weight=None, reduction='mean'):
        return F.cross_entropy(input, target, weight=weight, reduction=reduction)

class LinkPredictionLoss(nn.Module):
    def __init__(self):
        super(LinkPredictionLoss, self).__init__()

    def forward(self, input, target, weight=None, reduction='mean'):
        return F.binary_cross_entropy_with_logits(input, target, weight=weight, reduction=reduction)


class CBLoss(nn.Module):
    def __init__(self, beta=0.9999, num_classes=None, samples_per_class=None):
        super(CBLoss, self).__init__()
        self.beta = beta
        if samples_per_class is not None:
            # 计算每个类别的权重
            effective_num = 1.0 - torch.pow(self.beta, samples_per_class)
            weights = (1.0 - self.beta) / effective_num
            weights = weights / torch.sum(weights) * num_classes  
            self.register_buffer('weights', weights)
        else:
            self.register_buffer('weights', None)

    def forward(self, logits, targets):
        # 标准交叉熵损失
        ce_loss = F.cross_entropy(logits, targets, reduction='none')

        if self.weights is not None:
            # 为每个样本分配其对应类别的权重
            weights = self.weights[targets]
            cb_loss = weights * ce_loss
            return cb_loss.mean()
        else:
            return ce_loss.mean()



def generate_ground_truth_link_labels(edge):
    edge_index = edge
    num_edges = edge_index.size(1)
    ground_truth_link_labels = torch.ones(1, num_edges)
    return ground_truth_link_labels


class EMA:
    def __init__(self, beta, n_cls, U, device):
        self.beta = beta
        self.n_cls = n_cls
        self.U = U
        self.device = device
        # self.values = {i: 0.0 for i in range(n_cls)}  # 初始化所有类别的EMA值为0,字典
        self.values = {i: torch.tensor(0.0, device=device) for i in range(n_cls)}

    def update(self, confidence_scores, t_mask):
        with torch.no_grad():
            for class_index in range(self.n_cls):

                class_scores = confidence_scores[:, class_index]
                mask = class_scores >= confidence_scores.max(dim=1)[0]
                mask = mask & t_mask
                node_indices = torch.nonzero(mask, as_tuple=False).squeeze()



                if (not mask.any()) | (node_indices.numel() == 0):
                    self.values[class_index] = torch.tensor(-1.0, device=self.device)
                    continue


                if self.values[class_index] == 0.0:
                    self.values[class_index] = ((confidence_scores[:, class_index][node_indices] * \
                                                 (1 - self.U)[node_indices]).mean().item())
                else:
                    self.values[class_index] = (self.beta * self.values[class_index] + (1 - self.beta) * \
                                                ((confidence_scores[:, class_index][node_indices] * (1 - self.U)[node_indices])).mean().item())




    def get_value(self):
        return self.values

    def to(self, device):
        for key in self.values:
            self.values[key] = self.values[key].to(device)
        self.device = device
        return self



class ReNodeLoss(nn.Module):
    def __init__(self, alpha=0.1, w_min=0.5, w_max=2.0, train_idx=None, use_class_balance=False, device=None, dataset_name="Unknown"):

        super(ReNodeLoss, self).__init__()
        self.alpha = alpha
        self.w_min = w_min
        self.w_max = w_max
        self.use_class_balance = use_class_balance
        self.device = device if device is not None else torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.dataset_name = dataset_name


        self.register_buffer('dummy', torch.tensor(0, device=self.device))

        # 缓存
        self.P_cache = None
        self.T_cache = None

    def compute_pagerank_matrix(self, edge_index, num_nodes, target_nodes, eps=1e-3, max_iter=100,
                                                                 batch_size=128, norm_type="row"):

        adj = torch.sparse_coo_tensor(
            edge_index,
            torch.ones(edge_index.size(1), dtype=torch.float32, device=self.device),
            size=(num_nodes, num_nodes),
            device=self.device
        ).coalesce()


        deg = torch.sparse.sum(adj, dim=1).to_dense()

        if norm_type == "row":

            deg_inv = torch.where(deg > 0, 1.0 / deg, torch.zeros_like(deg))
            row, col = adj.indices()
            vals = adj.values() * deg_inv[row]
            adj_norm = torch.sparse_coo_tensor(torch.stack([row, col]), vals,
                                               (num_nodes, num_nodes)).coalesce()

        elif norm_type == "sym":

            deg_inv_sqrt = torch.where(deg > 0, deg.pow(-0.5), torch.zeros_like(deg))
            row, col = adj.indices()
            vals = adj.values() * deg_inv_sqrt[row] * deg_inv_sqrt[col]
            adj_norm = torch.sparse_coo_tensor(torch.stack([row, col]), vals,
                                               (num_nodes, num_nodes)).coalesce()
        else:
            raise ValueError(f"Unknown norm_type {norm_type}")
        results = []
        # 按批处理 target_nodes
        for start in range(0, len(target_nodes), batch_size):
            batch_nodes = target_nodes[start:start + batch_size]
            # 初始化多源向量 [N × B]
            B = len(batch_nodes)
            p = torch.zeros(num_nodes, B, device=self.device)
            for i, src in enumerate(batch_nodes):
                p[src, i] = 1.0
            r = p.clone()
            # 逐节点收敛检查
            for _ in range(max_iter):
                p_new = self.alpha * r + (1 - self.alpha) * torch.sparse.mm(adj_norm.t(), p)
                diff = torch.norm(p_new - p, p=1, dim=0)  # [B]
                active = diff >= eps
                if not active.any():
                    break
                p[:, active] = p_new[:, active]
            results.append(p.T)  # [B × N]
        return torch.cat(results, dim=0)  # |target_nodes| × N

    def compute_totoro(self, P, labeled_nodes, labels, num_classes):


        T = torch.zeros(len(labeled_nodes), device=P.device)

        for i, v in enumerate(labeled_nodes):
            P_v = P[i]
            conflict = 0.0
            for j in range(num_classes):
                if j != labels[i]:
                    class_j_idx = (labels == j).nonzero(as_tuple=True)[0]
                    if len(class_j_idx) > 0:
                        P_class_j = P[class_j_idx].mean(dim=0)
                        conflict += torch.sum(P_v * P_class_j)
        return T
    def compute_renode_weights(self, T):

        rank = torch.argsort(T)
        w = self.w_min + 0.5 * (self.w_max - self.w_min) * (1 + torch.cos(rank.float() / len(T) * np.pi))
        return w


    def weighted_cross_entropy(self, input, target, sample_weights):

        log_probs = F.log_softmax(input, dim=1)
        nll_loss = -log_probs.gather(1, target.unsqueeze(1)).squeeze()
        weighted_loss = (nll_loss * sample_weights).mean()
        return weighted_loss


    def forward(self, logits, labels, edge_index, labeled_mask, num_classes):

        edge_index = edge_index.to(self.device)
        labels = labels.to(self.device)
        logits = logits.to(self.device)
        # labeled_nodes代表训练集(标记节点)的索引，y_labeled标记节点的类别
        labeled_nodes = torch.where(labeled_mask)[0]
        y_labeled = labels[labeled_mask]

        if self.P_cache is None or self.T_cache is None:

            split_hash = hashlib.md5(str(labeled_nodes.cpu().tolist()).encode('utf-8')).hexdigest()[:8]


            cache_dir = "renode_cache"
            os.makedirs(cache_dir, exist_ok=True)


            cache_file = os.path.join(cache_dir, f"{self.dataset_name}_PPR_T_cache_{split_hash}.pt")

            if os.path.exists(cache_file):

                self.P_cache, self.T_cache = torch.load(cache_file, map_location=self.device)
            else:

                self.P_cache = self.compute_pagerank_matrix(edge_index, len(labels), labeled_nodes)
                self.T_cache = self.compute_totoro(self.P_cache, labeled_nodes, y_labeled, num_classes)

                torch.save((self.P_cache, self.T_cache), cache_file)



        w_renode = self.compute_renode_weights(self.T_cache).to(logits.device)

        if self.use_class_balance:
            class_counts = torch.bincount(y_labeled, minlength=num_classes)

            class_counts = torch.where(class_counts == 0, torch.ones_like(class_counts), class_counts)
            class_weights = (1.0 / class_counts) * (len(y_labeled) / num_classes)

            w_class = class_weights[y_labeled]
        else:
            w_class = torch.ones_like(w_renode)  # 如果不使用类别平衡

        w_total = w_renode * w_class

        loss = self.weighted_cross_entropy(logits[labeled_mask], y_labeled, w_total)
        return loss

