# Uncertainty_measure.py
import os
import os.path as osp
import tqdm
import random
import numpy as np
import torch
import torch.nn.functional as F
from args import parse_args
from data_utils import get_dataset
from torch_geometric.data import Data
import networkx as nx
import community as community_louvain



args = parse_args()
device = torch.device(args.device)



def node_homo(x, edge_index):
    num_nodes = x.shape[0]
    homogeneity = torch.zeros(num_nodes, dtype=torch.float)
    for node in range(num_nodes):
        neighbors = edge_index[0, edge_index[1] == node]
        if neighbors.numel() > 0:  # 检查neighbors是否为空
            distances = torch.norm(x[node] - x[neighbors], dim=1)
            homogeneity[node] = distances.mean().item()  # 使用.item()确保结果是一个标量
        else:
            homogeneity[node] = 0.0
    return homogeneity


#社区划分
def community_div(edge_index, num_nodes):
    edge_index_numpy = edge_index.cpu().numpy()
    G = nx.from_edgelist(edge_index_numpy.T)
    partition = community_louvain.best_partition(G)
    community_labels = [-1] * num_nodes
    for node in partition:
        community_labels[node] = partition[node]
    # community_labels = list(partition.values())
    community_tensor = torch.tensor(community_labels, dtype=torch.long)
    community_tensor = community_tensor.to(device)
    return community_tensor


def calculate_entropy(labels):


    labels = labels[labels != -1]
    if len(labels) == 0:
        return 0.0

    unique_labels, counts = torch.unique(labels, return_counts=True)
    probabilities = counts.float() / counts.sum().float()
    entropy = -torch.sum(probabilities * torch.log2(probabilities))
    return entropy



def com_entropy(edge_index, num_nodes, comm_class):

    comm_class = comm_class.to(device)
    edge_index = edge_index.to(device)
    node_entropy = torch.zeros(num_nodes, dtype=torch.float32, device=device)
    for node in range(num_nodes):
        if comm_class[node] == -1:
            node_entropy[node] = 0.0
        else:
            neighbors = edge_index[0, edge_index[1] == node]
            neighbor_community_labels = comm_class[neighbors]
            if len(neighbor_community_labels) > 0:
                node_entropy[node] = calculate_entropy(neighbor_community_labels)
            else:
                node_entropy[node] = 0.0
    return node_entropy



def degree_score(edge_index, num_nodes):
    node_degree = torch.zeros(num_nodes, dtype=torch.long, device=device)
    unique_labels, counts = torch.unique(edge_index[1], return_counts=True)
    node_degree[unique_labels] = counts

    degree_sc = 1.0 / (node_degree + 1)

    return degree_sc

def unce_score(x, edge_index):
    if args.dataset in ['Amazon-Computers', 'Amazon-Photo']:

        edge_index = torch.flip(edge_index, dims=[0])

    num_nodes = x.shape[0]
    comm_class = community_div(edge_index, num_nodes)
    homogeneity = node_homo(x, edge_index).to(device)
    node_entropy = com_entropy(edge_index, num_nodes, comm_class)
    degree_sc = degree_score(edge_index, num_nodes)
    structure = degree_sc * node_entropy

    U = homogeneity * structure
    U_min = U.min()
    U_max = U.max()
    U_normalized = 0.5 * (U - U_min) / (U_max - U_min)
    return U_normalized


def compute_uncertainty(x, edge_index, quantile_low=0.01, quantile_high=0.99, gamma=1.0, device=None):

    if args.dataset in ['Amazon-Computers', 'Amazon-Photo']:
        edge_index = torch.flip(edge_index, dims=[0])

    num_nodes = x.shape[0]
    comm_class = community_div(edge_index, num_nodes)

    homogeneity = node_homo(x, edge_index).to(device)

    node_entropy = com_entropy(edge_index, num_nodes, comm_class)

    degree_sc = degree_score(edge_index, num_nodes)

    structure = degree_sc * node_entropy
    U = homogeneity * structure


    low_val = float(torch.quantile(U, quantile_low))
    high_val = float(torch.quantile(U, quantile_high))
    eps = 1e-12
    if high_val - low_val < eps:
        low_val = U.min().item()
        high_val = U.max().item()
        if high_val - low_val < eps:
            return torch.zeros_like(U, device=device), {'low': low_val, 'high': high_val, 'gamma': gamma}

    U_clipped = torch.clamp(U, min=low_val, max=high_val)
    U_norm = (U_clipped - low_val) / (high_val - low_val + eps)  # [0,1]
    return U_norm, {'low': low_val, 'high': high_val, 'gamma': gamma}


