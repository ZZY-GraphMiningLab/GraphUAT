# main.py
import os
import os.path as osp
import time
import random
import numpy as np
import torch
import torch.nn.functional as F
from args import parse_args
from data_utils import get_dataset, get_idx_info, make_longtailed_data_remove, get_step_split, gen_masks_amazon
from nets import create_gcn, create_gat, create_sage
from utils import CrossEntropy, LinkPredictionLoss, CBLoss, ReNodeLoss, generate_ground_truth_link_labels, EMA
from Uncertainty_measure import unce_score, compute_uncertainty
from sklearn.metrics import balanced_accuracy_score, f1_score
from sklearn.utils.class_weight import compute_class_weight
import warnings
import copy as cp
import scipy.sparse as sp
from scipy.io import loadmat
warnings.filterwarnings("ignore")


Runs = 1


global data_train_mask, data_val_mask, data_test_mask
def train(model, data, ground_truth_link_labels, U, args):
    label_counts = torch.bincount(data.y[data_train_mask])
    max_samples = label_counts.max()
    saved_train_mask = data_train_mask.clone()
    saved_label = data.y.clone()
    train_idx = data_train_mask.nonzero().squeeze()
    pse_num = torch.zeros(n_cls, dtype=torch.int)
    ema = EMA(args.beta, n_cls, U, device).to(device)

    criterion_renode = ReNodeLoss(alpha=0.15, w_min=0.5, w_max=2.0, train_idx=train_idx,
                                  use_class_balance=True, device=device, dataset_name=args.dataset)

    best_val_acc_f1 = 0
    best_acc = best_bacc = best_f1 = 0.0


    rew = saved_label[saved_train_mask]
    classes = np.unique(rew.cpu().numpy())
    weights = compute_class_weight('balanced', classes=classes, y=rew.cpu().numpy())
    weights = torch.tensor(weights, dtype=torch.float32).to(rew.device)


    average_count = label_counts.float().mean().item()
    if args.label == 'mean':

        adjusted_counts = torch.full_like(label_counts, int(average_count))
    elif args.label == 'max':

        adjusted_counts = torch.full_like(label_counts, int(label_counts.max().item()))

    ad = torch.clamp(adjusted_counts - label_counts, min=0)
    ad = ad //10




    for i in range(args.epoch):
        model.train()
        optimizer.zero_grad()

        output = model(data.x, data.edge_index[:, train_edge_mask])


        if i <= 200:

            clas_out = criterion_renode(output, saved_label, data.edge_index[:, train_edge_mask], data_train_mask, n_cls)
            link = model.decode(output, data.edge_index[:, train_edge_mask]).unsqueeze(0)
            link_out = link_pred(link, ground_truth_link_labels)
            loss = (1 - args.alpha) * clas_out + args.alpha * link_out
        else:
            clas_out = criterion(output[saved_train_mask], saved_label[saved_train_mask])
            loss = clas_out

        loss.backward()
        optimizer.step()


        output_1 = model(data.x, data.edge_index[:, train_edge_mask])
        val_loss = F.cross_entropy(output_1[data_val_mask], data.y[data_val_mask])
        scheduler.step(val_loss)

        if i > 200 and i % 10 == 0 and i < 351:

            pse_num.fill_(0)

            new_train_c = torch.bincount(saved_label[saved_train_mask]).log()


            output = model(data.x, data.edge_index[:, train_edge_mask])
            confidence_scores = F.softmax((output - new_train_c), dim=1)


            ema.update(confidence_scores, (data_test_mask | data_val_mask) & (~ saved_train_mask))

            threshold_dict = ema.get_value()
            for label in range(n_cls):
                label_count = torch.bincount(saved_label[saved_train_mask], minlength=n_cls)
                if label_count[label] >= max_samples or threshold_dict[label] == -1:
                    continue

                predicted_labels = confidence_scores.argmax(dim=1)
                predicted_as = predicted_labels == label

                confidencetimesuncertainty = confidence_scores[ :, label] * (1 - U)


                highconfidencenodes = torch.nonzero(confidencetimesuncertainty > threshold_dict[label]).squeeze()
                mask = torch.zeros(data.x.shape[0]).bool()
                mask = mask.to(device)
                mask[highconfidencenodes] = True
                mask = mask & predicted_as


                select_mask = (data_test_mask | data_val_mask) & mask & (~ saved_train_mask)



                indices_0 = select_mask.nonzero().squeeze()

                if indices_0.numel() == 0:
                    pse_num[label] = 0
                    continue


                n_select = min(ad[label], indices_0.numel())
                _, indices = torch.topk(confidencetimesuncertainty[select_mask], n_select, largest=True, sorted=True)
                indices = torch.where(select_mask)[0][indices]
                pse_num[label] = n_select


                saved_train_mask[indices] = True
                saved_label[indices] = label

        model.eval()
        with torch.no_grad():
            accs, baccs, f1s = test(model, data)
        train_acc, val_acc, tmp_test_acc = accs
        train_bacc, val_bacc, tmp_test_bacc = baccs
        train_f1, val_f1, tmp_test_f1 = f1s
        val_acc_f1 = (val_acc + val_f1) / 2.
        if val_acc_f1 > best_val_acc_f1:
            best_val_acc_f1 = val_acc_f1
            best_acc = tmp_test_acc
            best_bacc = tmp_test_bacc
            best_f1 = tmp_test_f1


    label_count2 = torch.bincount(data.y[saved_train_mask], minlength=n_cls)

    correct_predictions = (saved_label[saved_train_mask & (~ data_train_mask)] == data.y[saved_train_mask & (~ data_train_mask)]).sum().item()
    total_pseudo_labels = len(saved_label[saved_train_mask & (~ data_train_mask)])

    pseudo_mask = saved_train_mask & (~data_train_mask)
    t = data.y[pseudo_mask]
    p = saved_label[pseudo_mask]
    tot = torch.bincount(t, minlength=n_cls).float()
    corr = torch.bincount(t[t == p], minlength=n_cls).float()
    acc = corr / tot.clamp(min=1)
    acc[tot == 0] = float('nan')

    print(f"这一轮的训练结果：best_acc:{best_acc:.3f}, best_bacc:{best_bacc:.3f}, best_f1:{best_f1:.3f}")
    return best_acc, best_bacc, best_f1



@torch.no_grad()
def test(model, data):
    model.eval()
    logits = model(data.x, data.edge_index[:, train_edge_mask])

    probs = F.softmax(logits, dim=1)
    _, predicted_classes = torch.max(probs, dim=1)

    accs, baccs, f1s, class_accs= [], [], [], []
    for mask in [data_train_mask, data_val_mask, data_test_mask]:
        pred = logits[mask].max(1)[1]
        y_pred = pred.cpu().numpy()
        y_true = data.y[mask].cpu().numpy()
        acc = pred.eq(data.y[mask]).sum().item() / mask.sum().item()
        bacc = balanced_accuracy_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred, average='macro')
        accs.append(acc)
        baccs.append(bacc)
        f1s.append(f1)

    return accs, baccs, f1s

args = parse_args()
seed = args.seed
device = torch.device(args.device)


torch.cuda.empty_cache()
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
random.seed(seed)
np.random.seed(seed)

best_test_results = []
abla = []

for run in range(Runs):
    path = args.data_path
    path = osp.join(path, args.dataset)
    dataset = get_dataset(args.dataset, path, split_type='full')
    data = dataset[0]
    n_cls = data.y.max().item() + 1
    data = data.to(device)

    unique_values, counts = torch.unique(data.y, return_counts=True)

    min_class_min = torch.min(counts)
    class_train_num = counts / min_class_min
    class_train_num_list = class_train_num.tolist()
    int_list = [int(float(item * 5)) for item in class_train_num_list]


    if args.dataset in ['Cora', 'CiteSeer', 'PubMed']:
        data_train_mask, data_val_mask, data_test_mask = data.train_mask.clone(), data.val_mask.clone(), data.test_mask.clone()
        stats = data.y[data_train_mask]
        n_data = []
        for i in range(n_cls):
            data_num = (stats == i).sum()
            n_data.append(int(data_num.item()))
        idx_info = get_idx_info(data.y, n_cls, data_train_mask)
        class_num_list, data_train_mask, idx_info, train_node_mask, train_edge_mask = \
            make_longtailed_data_remove(data.edge_index, data.y, n_data, n_cls, args.imb_ratio, data_train_mask.clone())
        train_idx = data_train_mask.nonzero().squeeze()

        labels_local = data.y.view([-1])[train_idx]
        train_idx_list = train_idx.cpu().tolist()
        local2global = {i: train_idx_list[i] for i in range(len(train_idx_list))}
        global2local = dict([val, key] for key, val in local2global.items())
        idx_info_list = [item.cpu().tolist() for item in idx_info]
        idx_info_local = [torch.tensor(list(map(global2local.get, cls_idx))) for cls_idx in idx_info_list]

    elif args.dataset in ['Amazon-Computers', 'Amazon-Photo', 'YelpChi','Amazon']:

        if args.dataset ==  'Amazon':
            train_min_class = 100
            val_min_class = 150
        else:
            train_min_class = 20
            val_min_class = 30

        data.train_mask, data.val_mask, data.test_mask = gen_masks_amazon(data.y, class_train_num_list, train_min_class, val_min_class, 1)
        data.train_mask, data.val_mask, data.test_mask = torch.squeeze(data.train_mask, 1), \
                                                         torch.squeeze(data.val_mask, 1), \
                                                         torch.squeeze(data.test_mask, 1)
        data_train_mask, data_val_mask, data_test_mask = data.train_mask.clone(), data.val_mask.clone(), data.test_mask.clone()
        data_train_mask = data_train_mask.to(device)
        data_val_mask = data_val_mask.to(device)
        data_test_mask = data_test_mask.to(device)
        train_idx = data_train_mask.nonzero().squeeze()
        train_edge_mask = torch.ones(data.edge_index.shape[1], dtype=torch.bool)


        stats = data.y[data_train_mask]
        n_data = []
        for i in range(n_cls):
            data_num = (stats == i).sum()
            n_data.append(int(data_num.item()))
        idx_info = get_idx_info(data.y, n_cls, data_train_mask)
        class_num_list = n_data
        train_node_mask = torch.ones(data.x.shape[0], dtype=torch.bool)

    else:
        raise NotImplementedError



    if run == 0:

        train_labels = data.y[data_train_mask]
        test_labels = data.y[data_test_mask]
        val_labels = data.y[data_val_mask]
        train_class_counts = torch.bincount(train_labels)
        test_class_counts = torch.bincount(test_labels)
        val_class_counts = torch.bincount(val_labels)



    if args.net == 'GCN':
        model = create_gcn(nfeat=dataset.num_features, nhid=args.feat_dim, nclass=n_cls, dropout=0.5,
                           nlayer=args.n_layer)
    elif args.net == 'GAT':
        model = create_gat(nfeat=dataset.num_features, nhid=args.feat_dim, nclass=n_cls, dropout=0.5,
                           nlayer=args.n_layer)
    elif args.net == "SAGE":
        model = create_sage(nfeat=dataset.num_features, nhid=args.feat_dim, nclass=n_cls, dropout=0.5,
                            nlayer=args.n_layer)
    else:
        raise NotImplementedError("Not Implemented Architecture!")

    model = model.to(device)
    criterion = CrossEntropy().to(device)
    link_pred = LinkPredictionLoss().to(device)
    U = unce_score(data.x, data.edge_index[:, train_edge_mask]).to(device)

    optimizer = torch.optim.Adam(
        [dict(params=model.reg_params, weight_decay=5e-4), dict(params=model.non_reg_params, weight_decay=0), ],
        lr=args.lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=100,
                                                           verbose=False)
    ground_truth_link_labels = generate_ground_truth_link_labels(data.edge_index[:,train_edge_mask])
    ground_truth_link_labels = ground_truth_link_labels.to(device)


    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
        print(f"--- Run {run} Training Started: Memory stats reset ---")


    accs, baccs, f1s = train(model, data, ground_truth_link_labels, U, args)
    best_test_results.append({
        'acc': accs,
        'bacc': baccs,
        'f1': f1s,
    })


    if torch.cuda.is_available():
        peak_memory = torch.cuda.max_memory_allocated(device) / (1024 ** 2)
        print(f"====> Run {run} Peak GPU Memory Usage: {peak_memory:.2f} MB <====")


avg_results = {}
std_results = {}
for key in best_test_results[0].keys():
    values = [result[key] for result in best_test_results]
    avg_results[key] = np.mean(values)
    std_results[key] = np.std(values)

#计算均值和标准差
avg_results = {key: value * 100 for key, value in avg_results.items()}
std_results = {key: value * 100 for key, value in std_results.items()}
# 打印结果
print('acc: {:.2f} ± {:.2f}, bacc: {:.2f} ± {:.2f}, f1: {:.2f} ± {:.2f}'.format(
    avg_results['acc'], std_results['acc'],
    avg_results['bacc'], std_results['bacc'],
    avg_results['f1'], std_results['f1']
))



