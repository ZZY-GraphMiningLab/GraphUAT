# data_utils.py
import torch
import os.path as osp
import numpy as np
from torch_scatter import scatter_add
from torch import Tensor
from typing import Optional, Tuple

from scipy.io import loadmat
from torch_geometric.data import Data

import scipy.io as sio
import scipy.sparse as sp
from torch_geometric.data import Data




def get_dataset(name, path, split_type='public'):
    import torch_geometric.transforms as T

    if name == "Cora" or name == "CiteSeer" or name == "PubMed":
        from torch_geometric.datasets import Planetoid
        dataset = Planetoid(path, name, transform=T.NormalizeFeatures(), split=split_type)
    elif name == 'Amazon-Computers':
        from torch_geometric.datasets import Amazon
        return Amazon(root=path, name='computers', transform=T.NormalizeFeatures())
    elif name == 'Amazon-Photo':
        from torch_geometric.datasets import Amazon
        return Amazon(root=path, name='photo', transform=T.NormalizeFeatures())

    # ================= 新增：YelpChi 的专属加载与处理 =================
    elif name == 'YelpChi':
        # 1. 读入mat格式的数据
        data_file = loadmat(osp.join(path, 'YelpChi.mat'))
        # 2. 处理特征与标签
        feat_data = data_file['features'].todense().A  # 转为稠密矩阵
        x = torch.FloatTensor(feat_data)
        labels = data_file['label'].flatten()
        y = torch.LongTensor(labels)
        # 3. 处理图拓扑结构 (融合三种关系并添加自循环)
        yelp_homo = data_file['net_rur'] + data_file['net_rtr'] + data_file['net_rsr']
        homo_adj = yelp_homo + sp.eye(yelp_homo.shape[0])
        # 提取边，构造成 PyG 能够识别的 [2, num_edges] 形状的 edge_index
        edges = homo_adj.nonzero()
        edge_index = torch.tensor(np.vstack((edges[0], edges[1])), dtype=torch.long)
        data = Data(x=x, edge_index=edge_index, y=y)
        # 4. 构造一个官方 Dataset 接口的包装类，让 main.py 里的通用代码能调用
        class YelpChiDataset:
            def __init__(self, data):
                self.data = data
                self.num_features = data.x.shape[1]
                self.num_classes = int(data.y.max().item()) + 1
            def __len__(self):
                return 1
            def __getitem__(self, idx):
                return self.data
        return YelpChiDataset(data)
    # ====================================================================

    # ================= 新增：Amazon 的专属加载与处理 =================
    elif name == 'Amazon':
        # 1. 读入mat格式的数据
        data_file = loadmat(osp.join(path, 'Amazon.mat'))
        # 2. 处理特征与标签
        feat_data = data_file['features'].todense().A  # 转为稠密矩阵
        x = torch.FloatTensor(feat_data)
        labels = data_file['label'].flatten()
        y = torch.LongTensor(labels)
        # 3. 处理图拓扑结构 (融合三种关系并添加自循环)
        yelp_homo = data_file['net_upu'] + data_file['net_usu'] + data_file['net_uvu']
        homo_adj = yelp_homo + sp.eye(yelp_homo.shape[0])
        # 提取边，构造成 PyG 能够识别的 [2, num_edges] 形状的 edge_index
        edges = homo_adj.nonzero()
        edge_index = torch.tensor(np.vstack((edges[0], edges[1])), dtype=torch.long)
        data = Data(x=x, edge_index=edge_index, y=y)
        # 4. 构造一个官方 Dataset 接口的包装类，让 main.py 里的通用代码能调用
        class AmazonDataset:
            def __init__(self, data):
                self.data = data
                self.num_features = data.x.shape[1]
                self.num_classes = int(data.y.max().item()) + 1
            def __len__(self):
                return 1
            def __getitem__(self, idx):
                return self.data
        return AmazonDataset(data)
    # ====================================================================

    else:
        raise NotImplementedError("Not Implemented Dataset!")

    return dataset



def gen_masks_amazon(y: Tensor,train_class_num_list ,train_min_class: int = 20, val_min_class: int = 30,
              num_splits: int = 1) -> Tuple[Tensor, Tensor, Tensor]:
    num_classes = int(y.max()) + 1

    train_mask = torch.zeros(y.size(0), num_splits, dtype=torch.bool)
    val_mask = torch.zeros(y.size(0), num_splits, dtype=torch.bool)
    for c in range(num_classes):
        idx = (y == c).nonzero(as_tuple=False).view(-1)
        perm = torch.stack(
            [torch.arange(idx.size(0)) for _ in range(num_splits)], dim=1)
        idx = idx[perm]
        train_idx = idx[:int(train_class_num_list[c]*train_min_class)]
        train_mask.scatter_(0, train_idx.cpu(), True)
        val_idx = idx[int(train_class_num_list[c]*train_min_class):int(train_class_num_list[c]*(train_min_class+val_min_class))]
        val_mask.scatter_(0, val_idx.cpu(), True)
    test_mask = ~(train_mask | val_mask)
    return train_mask, val_mask, test_mask




def get_idx_info(label, n_cls, train_mask):
    index_list = torch.arange(len(label))
    idx_info = []
    for i in range(n_cls):
        cls_indices = index_list[((label == i) & train_mask)]
        idx_info.append(cls_indices)
    return idx_info

def make_longtailed_data_remove(edge_index, label, n_data, n_cls, ratio, train_mask):
    # Sort from major to minor
    n_data = torch.tensor(n_data)
    sorted_n_data, indices = torch.sort(n_data, descending=True)
    inv_indices = np.zeros(n_cls, dtype=np.int64)
    for i in range(n_cls):
        inv_indices[indices[i].item()] = i
    assert (torch.arange(len(n_data))[indices][torch.tensor(inv_indices)] - torch.arange(len(n_data))).sum().abs() < 1e-12

    # Compute the number of nodes for each class following LT rules
    mu = np.power(1/ratio, 1/(n_cls - 1))
    n_round = []
    class_num_list = []
    for i in range(n_cls):
        assert int(sorted_n_data[0].item() * np.power(mu, i)) >= 1
        class_num_list.append(int(min(sorted_n_data[0].item() * np.power(mu, i), sorted_n_data[i])))
        """
        Note that we remove low degree nodes sequentially (10 steps)
        since degrees of remaining nodes are changed when some nodes are removed
        """
        if i < 1: # We does not remove any nodes of the most frequent class
            n_round.append(1)
        else:
            n_round.append(10)
    class_num_list = np.array(class_num_list)
    class_num_list = class_num_list[inv_indices]
    n_round = np.array(n_round)[inv_indices]

    # Compute the number of nodes which would be removed for each class
    remove_class_num_list = [n_data[i].item()-class_num_list[i] for i in range(n_cls)]
    remove_idx_list = [[] for _ in range(n_cls)]
    cls_idx_list = []
    index_list = torch.arange(len(train_mask))
    original_mask = train_mask.clone()
    for i in range(n_cls):
        cls_idx_list.append(index_list[(label == i) & original_mask])

    for i in indices.numpy():
        for r in range(1,n_round[i]+1):
            # Find removed nodes
            node_mask = label.new_ones(label.size(), dtype=torch.bool)
            node_mask[sum(remove_idx_list,[])] = False

            # Remove connection with removed nodes
            row, col = edge_index[0], edge_index[1]
            row_mask = node_mask[row]
            col_mask = node_mask[col]
            edge_mask = row_mask & col_mask

            # Compute degree
            degree = scatter_add(torch.ones_like(col[edge_mask]), col[edge_mask], dim_size=label.size(0)).to(row.device)
            degree = degree[cls_idx_list[i]]

            # Remove nodes with low degree first (number increases as round increases)
            # Accumulation does not be problem since
            _, remove_idx = torch.topk(degree, (r*remove_class_num_list[i])//n_round[i], largest=False)
            remove_idx = cls_idx_list[i][remove_idx]
            remove_idx_list[i] = list(remove_idx.numpy())

    # Find removed nodes
    node_mask = label.new_ones(label.size(), dtype=torch.bool)
    node_mask[sum(remove_idx_list,[])] = False

    # Remove connection with removed nodes
    row, col = edge_index[0], edge_index[1]
    row_mask = node_mask[row]
    col_mask = node_mask[col]
    edge_mask = row_mask & col_mask

    train_mask = node_mask & train_mask
    idx_info = []
    for i in range(n_cls):
        cls_indices = index_list[(label == i) & train_mask]
        idx_info.append(cls_indices)

    return list(class_num_list), train_mask, idx_info, node_mask, edge_mask

def get_step_split(imb_ratio, valid_each, labeling_ratio, all_idx, all_label, nclass):
    base_valid_each = valid_each

    head_list = [i for i in range(nclass//2)] 

    all_class_list = [i for i in range(nclass)]
    tail_list = list(set(all_class_list) - set(head_list))

    h_num = len(head_list)
    t_num = len(tail_list)

    base_train_each = int( len(all_idx) * labeling_ratio / (t_num + h_num * imb_ratio) )

    idx2train,idx2valid = {},{}

    total_train_size = 0
    total_valid_size = 0

    for i_h in head_list: 
        idx2train[i_h] = int(base_train_each * imb_ratio)
        idx2valid[i_h] = int(base_valid_each * 1) 

        total_train_size += idx2train[i_h]
        total_valid_size += idx2valid[i_h]

    for i_t in tail_list: 
        idx2train[i_t] = int(base_train_each * 1)
        idx2valid[i_t] = int(base_valid_each * 1)

        total_train_size += idx2train[i_t]
        total_valid_size += idx2valid[i_t]

    train_list = [0 for _ in range(nclass)]
    train_node = [[] for _ in range(nclass)]
    train_idx  = []

    for iter1 in all_idx:
        iter_label = all_label[iter1]
        if train_list[iter_label] < idx2train[iter_label]:
            train_list[iter_label]+=1
            train_node[iter_label].append(iter1)
            train_idx.append(iter1)

        if sum(train_list)==total_train_size:break

    assert sum(train_list)==total_train_size

    after_train_idx = list(set(all_idx)-set(train_idx))

    valid_list = [0 for _ in range(nclass)]
    valid_idx  = []
    for iter2 in after_train_idx:
        iter_label = all_label[iter2]
        if valid_list[iter_label] < idx2valid[iter_label]:
            valid_list[iter_label]+=1
            valid_idx.append(iter2)
        if sum(valid_list)==total_valid_size:break

    test_idx = list(set(after_train_idx)-set(valid_idx))

    return train_idx, valid_idx, test_idx, train_node


